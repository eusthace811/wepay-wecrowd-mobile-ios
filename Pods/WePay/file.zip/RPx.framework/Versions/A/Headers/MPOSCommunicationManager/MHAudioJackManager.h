//
//  MHAudioJackManager.h
//  MPOSCommunicationManager
//
//  Created by Wu Robert on 7/14/14.
//  Copyright (c) 2014 Landi 联迪. All rights reserved.
//

#import "AudioJackManager.h"

@interface MHAudioJackManager : AudioJackManager

+(MHAudioJackManager*)sharedInstance;

@end
